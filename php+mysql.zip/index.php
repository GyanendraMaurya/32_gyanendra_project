<?php
$con = mysqli_connect("localhost","root","oracle");
mysqli_select_db($con, 'wpform');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Index</title>
<link rel="stylesheet" type="text/css" href="social.css">

</head>
<body>

	<div class="container">
		<h3 style="text-align:center">Sign In</h3><hr>
		<div class="content">
			<form action="index.php" method="post">
				
				Username<br><input type ="text" name="username" placeholder="username"><br><br>
				Password:<br><input type="password" name="password" ><br><br>
				<input type="submit" name="signin" value="Sign In"><br>
				<a href="register.php"><input type="button" name="signup" value="Sign Up"><br><br></a>
			</form>
	
				
		</div>
	</div>
<?php
if(isset($_POST['signin']))
{
	$username= $_POST['username'];
	$password = $_POST['password'];
	$query = "select * from mytable where username = '$username' and password = '$password'";
	$query_run = mysqli_query($con, $query);
	if(mysqli_num_rows($query_run)>0)
	{
		 $_SESSION['message'] = $username;
		 header("location:homepage.php");
	}
	else{
		echo '<script type="text/javascript">alert("invalid credentials")</script>';
	}
}

?>
</body>
</html>