<?php
$con = mysqli_connect("localhost","root","oracle");
mysqli_select_db($con, 'wpform');
session_start();
?>


<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link rel="stylesheet" type="text/css" href="social.css">

</head>
<body>

	<div class="container">
		<h2 style="text-align:center">Home Page</h2><hr>
		<h3 style="text-align:center">Welcome <?php echo $_SESSION['message'] ?></h3><hr>
		<div class="content">
			
			<?php
				$name=$_SESSION['message'];
				$query= "select * from mytable where username= '$name'";
				$query_run= mysqli_query($con,$query);
				$row= mysqli_fetch_row($query_run);
			?>
				<i>Personal Information</i>
				<h4>Name : <?php printf("%s %s",$row[0],$row[1]);?></h4>
				<h4>Email : <?php printf("%s",$row[2]);?></h4>
				<h4>contact : <?php printf("%s",$row[3]);?></h4>
				<h4>gender : <?php printf("%s",$row[4]); ?></h4>
				
				
			
			<form action="homepage.php" method="post">
				<input type="submit" name="signout" value="Sign Out"><br>
			</form>
			<?php
				if(isset($_POST['signout']))
				{
					session_destroy();
					header('location:index.php');
				}
			?>
		</div>
	</div>
	</body>
	</html>
		