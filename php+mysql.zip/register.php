<?php
$con = mysqli_connect("localhost","root","oracle") or die("unable to connect");
mysqli_select_db($con, "wpform");

?>



<!DOCTYPE html>
<html>
<head>
<title>Sign Up</title>
<link rel="stylesheet" type="text/css" href="social.css">

</head>
<body>


	<div class="container">
		<h3 style="text-align:center">Registeration Form</h3><hr>
		<div class="content">
			<form action="register.php" method="post" onsubmit="return (vfirstname() && vlastname() && vcontact() && vpassword())" >
				First Name<br><input type ="text" id="firstname" name="firstname" placeholder="First name" required onblur="vfirstname()"><br><br>
				Last Name<br><input type ="text" id ="lastname" name="lastname" placeholder="Last name" required onblur="vlastname()"><br><br>
				Email<br><input type="text" name="email" placeholder="example@gmail.com"><br><br>
				Contact No.<br><input type="text" id = "contact"name = "contact" required onblur="vcontact()"><br><br>
				<table><tr>
				<td>Gender:</td><td><input type="radio" name ="gender" value="Male" checked>Male</td><td><input type="radio" name="gender" value="Female">Female</td></tr>
				</table>
				<br><br>
				Username<br><input type ="text" id = "username"name="username" placeholder="username" required><br><br>
				Password:<br><input type="password" id= "password" name="password" required><br><br>
				Confirm Password:<br><input type="password" id= "cpassword"name="cpassword" required onblur="vpassword()"><br><br>
				<input type="submit" name="signup" value="Sign Up">
				<a href="index.php"><input type="button" name="signin" value="Sign In"><br><br></a>
			</form>
				
		</div>
	</div>
<script type="text/javascript">
function vfirstname(){
	var name = document.getElementById("firstname").value;
	var letters=/^[A-Za-z]+$/;
	if(name.match(letters))
	{
		return true;
	}
	else{
		alert("Invalid FirstName");
		return false;
	}
}
function vlastname(){
	var name = document.getElementById("lastname").value;
	var letters=/^[A-Za-z]+$/;
	if(name.match(letters))
	{
		return true;
	}
	else{
		window.alert("Invalid LastName");
		return false;
	}
}
function vcontact(){
	var contact = document.getElementById("contact").value;
	var letters=/^[A-Za-z]+$/;
	if(contact.length!=10 || isNaN(contact))
	{
		window.alert("enter 10 digit phone no." );
		return false;
	}
	else{
		return true;
	}
}
function vpassword(){
	var p = document.getElementById("password").value;
	var pp = document.getElementById("cpassword").value;
	if(p!=pp)
	{
		alert("Passwords Does not match");
		return false;
	}
	else{ 
		return true;
	}
}

</script>
	<?php
		if(isset($_POST['signup']))
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$gender = $_POST['gender'];
			$contact = $_POST['contact'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			
			$query="select * from mytable where username='$username'";
			$query_run=mysqli_query($con,$query);
			if(mysqli_num_rows($query_run)>0)
			{
				echo '<script type= text/javascript>alert("username already exist..try other user name")</script>';
			}
			else{
				$query= "insert into mytable values('$firstname','$lastname','$email','$contact','$gender','$username','$password')";
				$query_run = mysqli_query($con,$query);
				if($query_run)
				{
					echo '<script type= text/javascript>alert("user registered")</script>';
				}
				else{
					echo '<script type= text/javascript>alert("error Registering user")</script>';
				}
				
			}
		}
	?>





</body>



</html>